$(document).ready(function() {
    $('#goButton').on('click', function() {
        window.location.href = 'next_page.html'; // Replace 'next_page.html' with the path to your next page
    });
});
